--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dbkos;
--
-- Name: dbkos; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE dbkos WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_Indonesia.1252';


ALTER DATABASE dbkos OWNER TO postgres;

\connect dbkos

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tbl_kamar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_kamar (
    id_kamar integer NOT NULL,
    nomor character varying(200),
    tipe character varying(200),
    harga bigint,
    status character varying(200)
);


ALTER TABLE public.tbl_kamar OWNER TO postgres;

--
-- Name: tbl_kamar_id_kamar_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tbl_kamar_id_kamar_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbl_kamar_id_kamar_seq OWNER TO postgres;

--
-- Name: tbl_kamar_id_kamar_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tbl_kamar_id_kamar_seq OWNED BY public.tbl_kamar.id_kamar;


--
-- Name: tbl_reservasi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_reservasi (
    id_reservasi integer NOT NULL,
    id_user bigint,
    id_kamar bigint,
    waktu character varying(200)
);


ALTER TABLE public.tbl_reservasi OWNER TO postgres;

--
-- Name: tbl_reservasi_id_reservasi_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tbl_reservasi_id_reservasi_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbl_reservasi_id_reservasi_seq OWNER TO postgres;

--
-- Name: tbl_reservasi_id_reservasi_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tbl_reservasi_id_reservasi_seq OWNED BY public.tbl_reservasi.id_reservasi;


--
-- Name: tbl_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_user (
    id_user integer NOT NULL,
    email character varying(200),
    password character varying(200),
    nama character varying(200),
    alamat character varying(200),
    no_hp bigint
);


ALTER TABLE public.tbl_user OWNER TO postgres;

--
-- Name: tbl_user_id_user_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tbl_user_id_user_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tbl_user_id_user_seq OWNER TO postgres;

--
-- Name: tbl_user_id_user_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tbl_user_id_user_seq OWNED BY public.tbl_user.id_user;


--
-- Name: tbl_kamar id_kamar; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_kamar ALTER COLUMN id_kamar SET DEFAULT nextval('public.tbl_kamar_id_kamar_seq'::regclass);


--
-- Name: tbl_reservasi id_reservasi; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_reservasi ALTER COLUMN id_reservasi SET DEFAULT nextval('public.tbl_reservasi_id_reservasi_seq'::regclass);


--
-- Name: tbl_user id_user; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_user ALTER COLUMN id_user SET DEFAULT nextval('public.tbl_user_id_user_seq'::regclass);


--
-- Data for Name: tbl_kamar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_kamar (id_kamar, nomor, tipe, harga, status) FROM stdin;
\.
COPY public.tbl_kamar (id_kamar, nomor, tipe, harga, status) FROM '$$PATH$$/3327.dat';

--
-- Data for Name: tbl_reservasi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_reservasi (id_reservasi, id_user, id_kamar, waktu) FROM stdin;
\.
COPY public.tbl_reservasi (id_reservasi, id_user, id_kamar, waktu) FROM '$$PATH$$/3329.dat';

--
-- Data for Name: tbl_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_user (id_user, email, password, nama, alamat, no_hp) FROM stdin;
\.
COPY public.tbl_user (id_user, email, password, nama, alamat, no_hp) FROM '$$PATH$$/3325.dat';

--
-- Name: tbl_kamar_id_kamar_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_kamar_id_kamar_seq', 43, true);


--
-- Name: tbl_reservasi_id_reservasi_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_reservasi_id_reservasi_seq', 7, true);


--
-- Name: tbl_user_id_user_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_user_id_user_seq', 13, true);


--
-- Name: tbl_kamar tbl_kamar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_kamar
    ADD CONSTRAINT tbl_kamar_pkey PRIMARY KEY (id_kamar);


--
-- Name: tbl_reservasi tbl_reservasi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_reservasi
    ADD CONSTRAINT tbl_reservasi_pkey PRIMARY KEY (id_reservasi);


--
-- Name: tbl_user tbl_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_user
    ADD CONSTRAINT tbl_user_pkey PRIMARY KEY (id_user);


--
-- Name: tbl_reservasi fk_id_kamar; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_reservasi
    ADD CONSTRAINT fk_id_kamar FOREIGN KEY (id_kamar) REFERENCES public.tbl_kamar(id_kamar) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tbl_reservasi fk_id_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_reservasi
    ADD CONSTRAINT fk_id_user FOREIGN KEY (id_user) REFERENCES public.tbl_user(id_user) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

